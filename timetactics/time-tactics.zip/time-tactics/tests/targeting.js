const vm=require('vm'),fs=require('fs');
const proxy=()=>new Proxy(function(){},{get:(t,k)=>k==='getImageData'?(()=>({data:new Uint8ClampedArray(32*32*4)})):k==='createRadialGradient'?(()=>({addColorStop(){}})):k==='canvas'?{}:proxy(),set:()=>true,apply:()=>proxy()});
const els={};const au=new Proxy({sampleRate:44100,currentTime:0,state:'running',createBuffer:()=>({getChannelData:()=>new Float32Array(44100)})},{get:(t,k)=>k in t?t[k]:()=>proxy()});const el=()=>({style:{},children:[],value:"5",checked:false,textContent:"",innerHTML:"",getContext:()=>proxy(),setPointerCapture(){},classList:{toggle(){},add(){},remove(){}},getBoundingClientRect:()=>({left:50,right:350,top:700,bottom:780}),addEventListener(){},appendChild(){},value:"16x16"});
const doc={getElementById:id=>els[id]||(els[id]=Object.assign(el(),{value:id.startsWith('t_')?'':id=="c_size"?"16x16":id=="c_den"?".05":"5"})),createElement:()=>el()};
const ctx=vm.createContext({document:doc,innerWidth:390,innerHeight:800,devicePixelRatio:1,addEventListener(){},requestAnimationFrame(){},ImageData:function(d,w,h){this.data=d},Math,console,location:{search:""},window:{AudioContext:function(){return au}},Date,localStorage:{getItem:()=>null},setTimeout,clearTimeout,Uint8Array,Int16Array,Uint8ClampedArray,Array,JSON,Set});
const order="balance enemies level state input rules flow sprites render fx main".split(" ");
for(const n of order){try{vm.runInContext(fs.readFileSync('../js/'+n+'.js','utf8'),ctx,{filename:n+'.js'})}catch(e){console.log("LOAD FAIL",n,e.stack.split("\n").slice(0,3).join("|"));process.exit(1)}}
const run=s=>vm.runInContext(s,ctx);


const T=`(function(){const out=[];
// 1) fair level stats
let pass=0,n=60,expo=0,tot=0,lop=0,t0=Date.now();
for(let i=0;i<n;i++){CFG={en:5,eh:5,sq:3,sh:5};genLevelOnce(16,16,.05);if(fairLevel())pass++}
out.push("first-attempt fair "+pass+"/"+n);
let bad=0,cnt=0,minDoor=99;
for(let g=0;g<30;g++){genLevel(16,16,.05);const open=[];for(let y=1;y<=ZY-4;y++)for(let x=1;x<W-1;x++)if(reach[y*W+x]&&!T[y*W+x]&&wk(x+.5,y+.5)&&doorSafe(x+.5,y+.5))open.push([x+.5,y+.5]);
 for(let i=0;i<5;i++){const sd=pool(open,i);if(!sd.length)continue;const a=sd[rnd(sd.length)];cnt++;if(!doorSafe(a[0],a[1]))bad++;minDoor=Math.min(minDoor,Math.hypot(a[0]-(W>>1)-.5,a[1]-ZY+.5))}}
out.push("genLevel ms/level "+((Date.now()-t0)/90).toFixed(1)+" unsafe starts "+bad+"/"+cnt+" minDoorDist "+minDoor.toFixed(1));
// arena for targeting tests
const tiles=[];for(let y=0;y<16;y++)for(let x=0;x<16;x++)tiles.push(x==0||y==0||x==15||y==15?2:0);
CUST={format:"tt-level",v:1,name:"arena",w:16,h:16,zy:16,tiles,objective:"eliminate",exit:null,items:[],n:0,target:null,secs:30,hostages:[],spawns:[{x:6.5,y:9.5},{x:8,y:9.5},{x:9.5,y:9.5}],
 enemies:[{type:"rifle",x:6.8,y:4.5,face:1.57,loop:"loop",path:[]},{type:"rifle",x:9.2,y:4.5,face:1.57,loop:"loop",path:[]}]};
$("c_lv").checked=true;deploy();setPause(true);
const [A,B,C]=players(),E=units.find(u=>u.team),F=units.filter(u=>u.team)[1];E.vis=F.vis=true;
// weakest-first AI (enemy E sees A and B)
A.x=7.5;A.y=8;B.x=7.8;B.y=8;A.hp=2;B.hp=5;C.x=3;C.y=13;[A,B,C].forEach(q=>q.mode="wait");
out.push("visible A="+canSee(E,A)+" B="+canSee(E,B)+" -> picks weakest A: "+(pickTgt(E).t===A));
A.hp=5;B.hp=2;out.push("swap hp -> picks B: "+(pickTgt(E).t===B));A.hp=5;B.hp=5;out.push("equal hp -> nearest: "+(pickTgt(E).t===(Math.hypot(E.x-A.x,E.y-A.y)<Math.hypot(E.x-B.x,E.y-B.y)?A:B)));
// manual targeting: C aims between E (left) and F (right)
C.x=8;C.y=9.5;C.crouch=false;C.pc=null;
const mL=manualPick(C,C.x,C.y,-Math.PI/2-.2,"wait"),mR=manualPick(C,C.x,C.y,-Math.PI/2+.2,"wait");
out.push("aim left of centre picks left enemy: "+(mL===E)+" ; right picks right enemy: "+(mR===F));
// issue via the real drag/commit path
sel=C;cmd="wait";menu();let p=w2s(C.x,C.y);cv.onpointerdown({pointerId:1,clientX:p.x,clientY:p.y,preventDefault(){}});
const q=w2s(C.x+Math.cos(-Math.PI/2+.2)*3,C.y+Math.sin(-Math.PI/2+.2)*3);cv.onpointermove({pointerId:1,clientX:q.x,clientY:q.y,preventDefault(){}});out.push("drag="+JSON.stringify(drag&&{t:drag.t,aim:drag.aim,mt:!!drag.mt,cx:drag.cx})+" Fvis="+F.vis+" ang="+Math.atan2(q.y-p.y,q.x-p.x).toFixed(2));out.push("drag preview target is F: "+(drag&&drag.mt===F));draw();
cv.onpointerup({pointerId:1,clientX:q.x,clientY:q.y,preventDefault(){}});out.push("committed mt is F: "+(C.mt===F));
// single enemy in cone -> no manual
F.alive=false;out.push("only one enemy in cone offers manual: "+!!manualPick(C,C.x,C.y,-Math.PI/2-.2,"wait"));F.alive=true;
// firing honours manual target, falls back when it dies
C.aim=-Math.PI/2+.2;C.face=C.aim;C.mt=F;out.push("pickTgt manual: "+(pickTgt(C).t===F));F.hp=0;F.alive=false;out.push("after death falls back: "+(pickTgt(C)===null||pickTgt(C).t!==F)+" mt="+C.mt);
setPause(false);for(let i=0;i<80;i++){update(.025);draw()}out.push("sim/draw ok state="+state);
return out.join(" || ")})()`;
try{console.log(run(T).split(" || ").join("\n"))}catch(e){console.log("RUNTIME FAIL",e.stack.split("\n").slice(0,6).join("\n"))}
